<?php $__env->startSection('main'); ?>
    <main id="main-container">
        <div class="content">
            <div
                class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center py-2 text-center text-md-start">
                <div class="flex-grow-1 mb-1 mb-md-0">
                    <h1 class="h3 fw-bold mb-2">
                        Trang chủ
                    </h1>
                    <h2 class="h6 fw-medium fw-medium text-muted mb-0">
                        Hệ thống quản trị -> Ver 1.2
                    </h2>
                </div>
                <div class="mt-3 mt-md-0 ms-md-3 space-x-1">
                    <form action="<?php echo e(route('admin.home')); ?>" method="get">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-alt js-flatpickr" id="dga-datepicker"
                                   data-date-format="yyyy-mm-dd"
                                   name="date"
                                   value="<?php if(!empty($_GET['date'])): ?><?php echo $_GET['date']?><?php else: ?><?php echo e(date('Y-m-d', time())); ?><?php endif; ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-search me-1"></i> Tìm
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="row items-push">
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['amount'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Tổng số tiền chơi</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['amountWin'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Số tiền thắng</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['amountLose'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Số tiền thua</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['amountSend'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Số tiền đã trả
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['turnWin'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Số lượt thắng
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['turnLose'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Số lượt thua
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <h2 class="content-heading">THỐNG KÊ HIỆN TẠI VÀ TRƯỚC</h2>
            <div class="row items-push">
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['today'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Doanh thu hôm nay</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['week'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Doanh thu tuần này</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['month'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">Doanh thu tháng này</dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['lastDay'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Doanh thu hôm trước
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['lastWeek'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Doanh thu tuần trước
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xxl-4">
                    <div class="block block-rounded d-flex flex-column h-100 mb-0">
                        <div
                            class="block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center">
                            <dl class="mb-0">
                                <dt class="fs-3 fw-bold"><?php echo e(number_format($total['lastMonth'])); ?></dt>
                                <dd class="fs-sm fw-medium fs-sm fw-medium text-muted mb-0">
                                    Doanh thu tháng trước
                                </dd>
                            </dl>
                            <div class="item item-rounded-lg bg-body-light">
                                <i class="far fa-money-bill-1 fs-3 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="block block-rounded block-mode-hidden">
                <div class="block-header block-header-default">
                    <h3 class="block-title">THÔNG KÊ
                        NGÀY <?php if(!empty($_GET['date'])): ?> <?php echo $_GET['date'] ?> <?php else: ?> <?php echo e(date('Y-m-d', time())); ?> <?php endif; ?></h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="fullscreen_toggle"><i class="si si-size-fullscreen"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="pinned_toggle">
                            <i class="si si-pin"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="state_toggle" data-action-mode="demo">
                            <i class="si si-refresh"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="content_toggle"><i class="si si-arrow-up"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="close">
                            <i class="si si-close"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content">
                    <div class="col-lg-12">
                        <ul class="nav nav-tabs nav-tabs-alt nav-fill" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active" id="all-tab" data-bs-toggle="tab"
                                        data-bs-target="#all" role="tab"
                                        aria-controls="all" aria-selected="true">TẤT CẢ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanle-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanle" role="tab"
                                        aria-controls="chanle" aria-selected="false">CHẴN LẺ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanle2-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanle2" role="tab"
                                        aria-controls="chanle2" aria-selected="false">CHẴN LẺ 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiu-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiu" role="tab"
                                        aria-controls="taixiu" aria-selected="false">TÀI XỈU
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiu2-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiu2" role="tab"
                                        aria-controls="taixiu2" aria-selected="false">TÀI XỈU 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="phan3-tab" data-bs-toggle="tab"
                                        data-bs-target="#phan3" role="tab"
                                        aria-controls="phan3" aria-selected="false">1 PHẦN 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="gap3-tab" data-bs-toggle="tab"
                                        data-bs-target="#gap3" role="tab"
                                        aria-controls="gap3" aria-selected="false">GẤP 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="h3-tab" data-bs-toggle="tab"
                                        data-bs-target="#h3" role="tab"
                                        aria-controls="h3" aria-selected="false">H3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="lo-tab" data-bs-toggle="tab"
                                        data-bs-target="#lo" role="tab"
                                        aria-controls="lo" aria-selected="false">LÔ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="xien-tab" data-bs-toggle="tab"
                                        data-bs-target="#xien" role="tab"
                                        aria-controls="xien" aria-selected="false">XIÊN
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="xsmb-tab" data-bs-toggle="tab"
                                        data-bs-target="#xsmb" role="tab"
                                        aria-controls="xsmb" aria-selected="false">XSMB
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="all" role="tabpanel"
                                 aria-labelledby="all-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLDay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseALLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendALLDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLDay'] - $total['turnLoseALLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLDay'] - $total['amountSendALLDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanle" role="tabpanel"
                                 aria-labelledby="chanle-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLDay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCLDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLDay'] - $total['turnLoseCLDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLDay'] - $total['amountSendCLDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanle2" role="tabpanel"
                                 aria-labelledby="chanle2-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Day'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCL2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCL2Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Day'] - $total['turnLoseCL2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Day'] - $total['amountSendCL2Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiu" role="tabpanel"
                                 aria-labelledby="taixiu-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXDay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTXDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTXDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXDay'] - $total['turnLoseTXDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXDay'] - $total['amountSendTXDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiu2" role="tabpanel"
                                 aria-labelledby="taixiu2-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Day'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTX2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTX2Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Day'] - $total['turnLoseTX2Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Day'] - $total['amountSendTX2Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="phan3" role="tabpanel"
                                 aria-labelledby="phan3-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Day'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLose1P3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSend1P3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Day'] - $total['turnLose1P3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Day'] - $total['amountSend1P3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="gap3" role="tabpanel"
                                 aria-labelledby="gap3-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Day'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseG3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendG3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Day'] - $total['turnLoseG3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Day'] - $total['amountSendG3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="h3" role="tabpanel"
                                 aria-labelledby="h3-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Day'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseH3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendH3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Day'] - $total['turnLoseH3Day'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Day'] - $total['amountSendH3Day'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="lo" role="tabpanel"
                                 aria-labelledby="lo-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLODay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLODay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseLODay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendLODay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLODay'] - $total['turnLoseLODay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLODay'] - $total['amountSendLODay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="xien" role="tabpanel"
                                 aria-labelledby="xien-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinXienDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountXienDay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseXienDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendXienDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinXienDay'] - $total['turnLoseXienDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountXienDay'] - $total['amountSendXienDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="xsmb" role="tabpanel"
                                 aria-labelledby="xsmb-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinXSMBDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountXSMBDay'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseXSMBDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendXSMBDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinXSMBDay'] - $total['turnLoseXSMBDay'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountXSMBDay'] - $total['amountSendXSMBDay'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="block block-rounded block-mode-hidden">
                <div class="block-header block-header-default">
                    <h3 class="block-title">THÔNG KÊ TUẦN NÀY</h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="fullscreen_toggle"><i class="si si-size-fullscreen"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="pinned_toggle">
                            <i class="si si-pin"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="state_toggle" data-action-mode="demo">
                            <i class="si si-refresh"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="content_toggle"><i class="si si-arrow-up"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="close">
                            <i class="si si-close"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content">
                    <div class="col-lg-12">
                        <ul class="nav nav-tabs nav-tabs-alt nav-fill" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active" id="allweek-tab" data-bs-toggle="tab"
                                        data-bs-target="#allweek" role="tab"
                                        aria-controls="allweek" aria-selected="true">TẤT CẢ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanleweek-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanleweek" role="tab"
                                        aria-controls="chanleweek" aria-selected="false">CHẴN LẺ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanle2week-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanle2week" role="tab"
                                        aria-controls="chanle2week" aria-selected="false">CHẴN LẺ 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiuweek-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiuweek" role="tab"
                                        aria-controls="taixiuweek" aria-selected="false">TÀI XỈU
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiu2week-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiu2week" role="tab"
                                        aria-controls="taixiu2week" aria-selected="false">TÀI XỈU 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="phan3week-tab" data-bs-toggle="tab"
                                        data-bs-target="#phan3week" role="tab"
                                        aria-controls="phan3week" aria-selected="false">1 PHẦN 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="gap3week-tab" data-bs-toggle="tab"
                                        data-bs-target="#gap3week" role="tab"
                                        aria-controls="gap3week" aria-selected="false">GẤP 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="h3week-tab" data-bs-toggle="tab"
                                        data-bs-target="#h3week" role="tab"
                                        aria-controls="h3week" aria-selected="false">H3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="loweek-tab" data-bs-toggle="tab"
                                        data-bs-target="#loweek" role="tab"
                                        aria-controls="loweek" aria-selected="false">LÔ
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="allweek" role="tabpanel"
                                 aria-labelledby="allweek-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseALLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendALLWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLWeek'] - $total['turnLoseALLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLWeek'] - $total['amountSendALLWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanleweek" role="tabpanel"
                                 aria-labelledby="chanleweek-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLWeek'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCLWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLWeek'] - $total['turnLoseCLWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLWeek'] - $total['amountSendCLWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanle2week" role="tabpanel"
                                 aria-labelledby="chanle2week-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCL2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCL2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Week'] - $total['turnLoseCL2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Week'] - $total['amountSendCL2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiuweek" role="tabpanel"
                                 aria-labelledby="taixiuweek-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXWeek'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTXWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTXWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXWeek'] - $total['turnLoseTXWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXWeek'] - $total['amountSendTXWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiu2week" role="tabpanel"
                                 aria-labelledby="taixiu2week-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTX2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTX2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Week'] - $total['turnLoseTX2Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Week'] - $total['amountSendTX2Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="phan3week" role="tabpanel"
                                 aria-labelledby="phan3week-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLose1P3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSend1P3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Week'] - $total['turnLose1P3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Week'] - $total['amountSend1P3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="gap3week" role="tabpanel"
                                 aria-labelledby="gap3week-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Week'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseG3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendG3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Week'] - $total['turnLoseG3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Week'] - $total['amountSendG3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="h3week" role="tabpanel"
                                 aria-labelledby="h3week-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Week'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseH3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendH3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Week'] - $total['turnLoseH3Week'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Week'] - $total['amountSendH3Week'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="loweek" role="tabpanel"
                                 aria-labelledby="loweek-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLOWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-success">
                                                        Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLOWeek'])); ?> VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseLOWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-danger">
                                                        Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendLOWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLOWeek'] - $total['turnLoseLOWeek'])); ?></strong>
                                                    </td>
                                                    <td>
                                                    <span class="fw-semibold text-warning">
                                                        Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLOWeek'] - $total['amountSendLOWeek'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="block block-rounded block-mode-hidden">
                <div class="block-header block-header-default">
                    <h3 class="block-title">THÔNG KÊ THÁNG NÀY</h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="fullscreen_toggle"><i class="si si-size-fullscreen"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="pinned_toggle">
                            <i class="si si-pin"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="state_toggle" data-action-mode="demo">
                            <i class="si si-refresh"></i>
                        </button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="content_toggle"><i class="si si-arrow-up"></i></button>
                        <button type="button" class="btn-block-option" data-toggle="block-option"
                                data-action="close">
                            <i class="si si-close"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content">
                    <div class="col-lg-12">
                        <ul class="nav nav-tabs nav-tabs-alt nav-fill" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active" id="allmonth-tab" data-bs-toggle="tab"
                                        data-bs-target="#allmonth" role="tab"
                                        aria-controls="allmonth" aria-selected="true">TẤT CẢ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanlemonth-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanlemonth" role="tab"
                                        aria-controls="chanlemonth" aria-selected="false">CHẴN LẺ
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="chanle2month-tab" data-bs-toggle="tab"
                                        data-bs-target="#chanle2month" role="tab"
                                        aria-controls="chanle2month" aria-selected="false">CHẴN LẺ 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiumonth-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiumonth" role="tab"
                                        aria-controls="taixiumonth" aria-selected="false">TÀI XỈU
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="taixiu2month-tab" data-bs-toggle="tab"
                                        data-bs-target="#taixiu2month" role="tab"
                                        aria-controls="taixiu2month" aria-selected="false">TÀI XỈU 2
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="phan3month-tab" data-bs-toggle="tab"
                                        data-bs-target="#phan3month" role="tab"
                                        aria-controls="phan3month" aria-selected="false">1 PHẦN 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="gap3month-tab" data-bs-toggle="tab"
                                        data-bs-target="#gap3month" role="tab"
                                        aria-controls="gap3month" aria-selected="false">GẤP 3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="h3month-tab" data-bs-toggle="tab"
                                        data-bs-target="#h3month" role="tab"
                                        aria-controls="h3month" aria-selected="false">H3
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" id="lomonth-tab" data-bs-toggle="tab"
                                        data-bs-target="#lomonth" role="tab"
                                        aria-controls="lomonth" aria-selected="false">LÔ
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="allmonth" role="tabpanel"
                                 aria-labelledby="allmonth-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseALLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendALLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinALLMonth'] - $total['turnLoseALLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountALLMonth'] - $total['amountSendALLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanlemonth" role="tabpanel"
                                 aria-labelledby="chanlemonth-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCLMonth'] - $total['turnLoseCLMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCLMonth'] - $total['amountSendCLMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="chanle2month" role="tabpanel"
                                 aria-labelledby="chanle2month-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseCL2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendCL2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinCL2Month'] - $total['turnLoseCL2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountCL2Month'] - $total['amountSendCL2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiumonth" role="tabpanel"
                                 aria-labelledby="taixiumonth-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTXMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTXMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTXMonth'] - $total['turnLoseTXMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTXMonth'] - $total['amountSendTXMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="taixiu2month" role="tabpanel"
                                 aria-labelledby="taixiu2month-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseTX2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendTX2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinTX2Month'] - $total['turnLoseTX2Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountTX2Month'] - $total['amountSendTX2Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="phan3month" role="tabpanel"
                                 aria-labelledby="phan3month-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLose1P3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSend1P3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWin1P3Month'] - $total['turnLose1P3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amount1P3Month'] - $total['amountSend1P3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="gap3month" role="tabpanel"
                                 aria-labelledby="gap3month-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseG3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendG3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinG3Month'] - $total['turnLoseG3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountG3Month'] - $total['amountSendG3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="h3month" role="tabpanel"
                                 aria-labelledby="h3month-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseH3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendH3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinH3Month'] - $total['turnLoseH3Month'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountH3Month'] - $total['amountSendH3Month'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="lomonth" role="tabpanel"
                                 aria-labelledby="lomonth-tab">
                                <div class="block block-rounded">
                                    <div class="block-content block-content-full">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-vcenter">
                                                <tbody class="fs-sm">
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số lượt thắng</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLOMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-success">
                                            Số tiền nhận</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLOMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số lượt thua</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnLoseLOMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-danger">
                                            Số tiền trả</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountSendLOMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Thắng / thua </span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['turnWinLOMonth'] - $total['turnLoseLOMonth'])); ?></strong>
                                                    </td>
                                                    <td>
                                        <span class="fw-semibold text-warning">
                                            Lãi</span>
                                                    </td>
                                                    <td class="d-none d-sm-table-cell text-end">
                                                        <strong><?php echo e(number_format($total['amountLOMonth'] - $total['amountSendLOMonth'])); ?>

                                                            VND</strong>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-xxl-12 d-flex flex-column">
                    <div class="block block-rounded flex-grow-1 d-flex flex-column">
                        <div class="block-header block-header-default">
                            <h3 class="block-title">DOANH THU 7 NGÀY GẦN NHẤT</h3>
                        </div>
                        <div class="block-content block-content-full flex-grow-1 d-flex align-items-center">
                            <canvas id="dga-chart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="block block-rounded">
                        <div class="block-header block-header-default">
                            <h3 class="block-title">
                                LỊCH SỬ CHƠI TUẦN NÀY
                            </h3>
                        </div>
                        <div class="block-content block-content-full">
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-responsive">
                                <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th style="width: 10%;">Số MOMO</th>
                                    <th>Đã chơi</th>
                                    <th>Đã thắng</th>
                                    <th>Đã thua</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $UserTopWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center fs-sm"><?php echo e($i++); ?></td>
                                        <td class="fw-semibold fs-sm"><?php echo e($row['phone']); ?></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountAll'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnAll'])); ?> lần</sub></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountWin'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnWin'])); ?> lần</sub></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountLose'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnLose'])); ?> lần</sub></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="block block-rounded">
                        <div class="block-header block-header-default">
                            <h3 class="block-title">
                                LỊCH SỬ CHƠI THÁNG NÀY
                            </h3>
                        </div>
                        <div class="block-content block-content-full">
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-responsive">
                                <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th style="width: 10%;">Số MOMO</th>
                                    <th>Đã chơi</th>
                                    <th>Đã thắng</th>
                                    <th>Đã thua</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $UserTopMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center fs-sm"><?php echo e($i++); ?></td>
                                        <td class="fw-semibold fs-sm"><?php echo e($row['phone']); ?></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountAll'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnAll'])); ?> lần</sub></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountWin'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnWin'])); ?> lần</sub></td>
                                        <td class="fw-semibold fs-sm"><?php echo e(number_format($row['amountLose'])); ?> VND /
                                            <sub><?php echo e(number_format($row['turnLose'])); ?> lần</sub></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            $.fn.datepicker.dates['vi'] = {
                days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                daysShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                daysMin: ["CN", "T2", "T3", "T4", "T", "T5", "T6"],
                months: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"],
                monthsShort: ["Th 1", "Th 2", "Th 3", "Th 4", "Th 5", "Th 6", "Th 7", "Th 8", "Th 9", "Th 10", "Th 11", "Th 12"],
                today: "Hôm nay",
                clear: "Xóa",
                format: "yyyy/mm/dd",
                titleFormat: "MM yyyy", /* Leverages same syntax as 'format' */
                weekStart: 0
            };
            $("#dga-datepicker").datepicker({
                language: "vi"
            });
        });
        let i = document.getElementById("dga-chart");
        let n = {
            labels: ["<?php echo e($day[7]); ?>", "<?php echo e($day[6]); ?>", "<?php echo e($day[5]); ?>", "<?php echo e($day[4]); ?>", "<?php echo e($day[3]); ?>", "<?php echo e($day[2]); ?>", "<?php echo e($day[1]); ?>"],
            datasets: [{
                label: "Tiền chơi",
                fill: !0,
                backgroundColor: "rgba(171, 227, 125, .5)",
                borderColor: "rgba(171, 227, 125, 1)",
                pointBackgroundColor: "rgba(171, 227, 125, 1)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(171, 227, 125, 1)",
                data: [<?php echo e($moneyDay[7]); ?>, <?php echo e($moneyDay[6]); ?>, <?php echo e($moneyDay[5]); ?>, <?php echo e($moneyDay[4]); ?>, <?php echo e($moneyDay[3]); ?>, <?php echo e($moneyDay[2]); ?>, <?php echo e($moneyDay[1]); ?>]
            }, {
                label: "Tiền thắng",
                fill: !0,
                backgroundColor: "#F47C7C",
                borderColor: "rgba(0, 0, 0, .3)",
                pointBackgroundColor: "rgba(0, 0, 0, .3)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0, 0, 0, .3)",
                data: [<?php echo e($receiveDay[7]); ?>, <?php echo e($receiveDay[6]); ?>, <?php echo e($receiveDay[5]); ?>, <?php echo e($receiveDay[4]); ?>, <?php echo e($receiveDay[3]); ?>, <?php echo e($receiveDay[2]); ?>, <?php echo e($receiveDay[1]); ?>]
            }, {
                label: "Tiền lãi",
                fill: !0,
                backgroundColor: "#FFE3A9",
                borderColor: "rgba(0, 0, 0, .3)",
                pointBackgroundColor: "rgba(0, 0, 0, .3)",
                pointBorderColor: "#fff",
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: "rgba(0, 0, 0, .3)",
                data: [<?php echo e($interestDay[7]); ?>, <?php echo e($interestDay[6]); ?>, <?php echo e($interestDay[5]); ?>, <?php echo e($interestDay[4]); ?>, <?php echo e($interestDay[3]); ?>, <?php echo e($interestDay[2]); ?>, <?php echo e($interestDay[1]); ?>]
            }]
        };
        new Chart(i, {
            type: "bar",
            data: n
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dgaAdmin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trumgo88/public_html/resources/views/dgaAdmin/home.blade.php ENDPATH**/ ?>